package bouncingballadvanced;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;


public class Twitter implements Shape{
    int x, y;
    int speedX, speedY;
    BufferedImage image;


    public Twitter(int x, int y, int speedX, int speedY) {
        this.x = x;
        this.y = y;
        this.speedX = speedX;
        this.speedY = speedY;
       try {
            this.image = ImageIO.read(new File("Luis.png"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void move(BallCage cage) {
        this.x += this.speedX;
        this.y += this.speedY;

        if (x < 1) {
            speedX = -speedX; // Reflect along normal
            x = 1;     // Re-position the ball at the edge
        } else if (x > cage.getWidth()-image.getWidth()) {
            speedX = -speedX;
            x = cage.getWidth()-image.getWidth();
        }
        // May cross both x and y bounds
        if (y < 1) {
            speedY = -speedY;
            y = 1;
        } else if (y > cage.getHeight()-image.getHeight()-150) {
            speedY = -speedY;
            y = cage.getHeight()-image.getHeight()-150;
        }
    }

    @Override
    public void draw(Graphics g) {
        g.drawImage(image, x, y, null);
    }
    
        public int getPosX(){
    return x;
    }
    
    public int getPosY(){
    return y;
    }
    
    public int getWidth(){
    return image.getWidth();
    }
    
    public int getHeight(){
    return image.getHeight();
    }
}
