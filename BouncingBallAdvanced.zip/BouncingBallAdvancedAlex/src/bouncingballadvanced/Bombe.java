/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bouncingballadvanced;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author Administrator
 */
public class Bombe implements Shape{

    private int x,y, speedX, speedY;
    private BufferedImage image;

    public Bombe(int x, int y, int speedX, int speedY) {
        try {
            this.x = x;
            this.y = y;
            this.speedX = speedX;
            this.speedY = speedY;
            image = ImageIO.read(new File("stone.png"));
        } catch (IOException ex) {
           ex.printStackTrace();
        }
    }
    
    
    
    
    
    @Override
    public void move(BallCage cage) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        this.x += this.speedX;
        this.y += this.speedY;   
        
        if (x < 1) {
            speedX = -speedX; // Reflect along normal
            x = 1;     // Re-position the ball at the edge
        } else if (x > cage.getWidth()-image.getWidth()) {
            speedX = -speedX;
            x = cage.getWidth()-image.getWidth();
        }
      // May cross both x and y bounds
        if (y < 1) {
            speedY = -speedY;
            y = 1;
        } else if (y > cage.getHeight()-image.getHeight()-60) {
            speedY = -speedY;
            y = cage.getHeight()-image.getHeight()-60;
        }
    }

    @Override
    public void draw(Graphics g) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       g.drawImage(image, x, y, null);
    }
    
    public int getPosX(){
    return x;
    }
    
    public int getPosY(){
    return y;
    }
    
    public int getWidth(){
    return image.getWidth();
    }
    
    public int getHeight(){
    return image.getHeight();
    }
}
