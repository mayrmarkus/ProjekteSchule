/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bouncingballadvanced;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Administrator
 */
public class BallWorld extends JFrame implements MouseListener, KeyListener {

    private BallCage cage;
    private DrawPanel panel;
    private ArrayList<Shape> shapes;
    private JButton add_button;
    private JButton remove_button;
    private Shooter shooter;
    private int windowHeight;
    private int windowWidth;

    public BallWorld(int w, int h) {

        shapes = new ArrayList<>();

        windowHeight = h;
        windowWidth = w;

        this.setSize(w, h);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cage = new BallCage(w, h, Color.white, Color.orange);
        shooter = new Shooter(windowWidth / 2, windowHeight - 40, 10, 50, 20, Color.black);
        panel = new DrawPanel(w, h, cage, shooter);

        setLayout(new BorderLayout());
        add(panel, BorderLayout.CENTER);
        addKeyListener(this);

//        Ball b1 = new Ball(5, 5, 5, 5, 5, Color.yellow);
//        shapes.add(b1);
//        panel.addShape(b1);
        JPanel btt_panel = new JPanel();
        this.add(btt_panel, BorderLayout.SOUTH);
        btt_panel.addKeyListener(this);
        add_button = new JButton();
        add_button.setText("ADD");
        add_button.setSize(100, 30);
        add_button.addMouseListener(this);
        add_button.setFocusable(false);
        btt_panel.add(add_button);

        remove_button = new JButton();
        remove_button.setText("REMOVE");
        remove_button.setSize(100, 30);
        remove_button.addMouseListener(this);
        remove_button.setFocusable(false);
        btt_panel.add(remove_button);
        if (shapes.isEmpty()) {
            remove_button.setEnabled(false);
        } else {
            remove_button.setEnabled(true);
        }
    }

    public void gameStart() {
        Thread gamethread = new Thread() {

            public void run() {
                while (true) {
                    gameUpdate();

                    repaint();

                    try {
                        Thread.sleep(1000 / 50);
                    } catch (InterruptedException ex) {

                    }
                }
            }
        };

        gamethread.start();

    }

    public void gameUpdate() {
        for (int i = 0; i < shapes.size(); i++) {
            shapes.get(i).move(cage);
        }
        removeHittedObjects();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
//        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Random rand = new Random();
        if (e.getSource().equals(add_button)) {
            for (int i = 0; i < 5; i++) {
                remove_button.setEnabled(true);
                //Bombe b = new Bombe(177, 115, rand.nextInt(15) + 10, rand.nextInt(15) + 10);
                Ball b = new Ball(rand.nextInt(100), rand.nextInt(100), rand.nextInt(10)+5, rand.nextInt(10)+5, rand.nextInt(20)+8, Color.BLUE);
                shapes.add(b);
                panel.addShape(b);
            }
        } else if (e.getSource().equals(remove_button)) {

            if (shapes.size() > 1) {

                int zahl = rand.nextInt(shapes.size());
                panel.removeObject(shapes.get(zahl));
                shapes.remove(zahl);
            } else if (shapes.size() == 1) {
                remove_button.setEnabled(false);
                panel.removeObject(shapes.get(0));
                shapes.remove(0);
            }

        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyTyped(KeyEvent e) {

        if (e.getKeyChar() == 'a') {
            shooter.move(cage, -1);
        } else if (e.getKeyChar() == 'd') {
            shooter.move(cage, 1);
        } else if (e.getKeyChar() == 'w') {
            Bullet b = new Bullet(shooter.getPosX() + (shooter.getWidth() / 2), panel.getHeight() - shooter.getHeight() - 10, 20, 5, Color.red);
            shapes.add(b);
            panel.addShape(b);
        } 
    }

    private void removeHittedObjects() {
        ArrayList<Shape> aux = new ArrayList<Shape>();
        for (int i = 0; i < shapes.size(); i++) {
            Shape s = shapes.get(i);
            if (s instanceof Bullet) {
                Bullet b = (Bullet) s;
                for (int j = 0; j < shapes.size(); j++) {
                    Shape t = shapes.get(j);
                    if (!(t instanceof Bullet)) {
                        if (t instanceof Ball) {
                            int xBullet = b.getPosX();
                            int yBullet = b.getPosY();
                            if (xBullet >= t.getPosX() - t.getWidth() && xBullet <= t.getPosX() + t.getWidth()
                                    && yBullet >= t.getPosY() - t.getHeight() && yBullet <= t.getPosY() + t.getHeight()) {
                                aux.add(t);
                                aux.add(b);
                            }
                        } else {
                            int xBullet = b.getPosX();
                            int yBullet = b.getPosY();
                            if (xBullet >= t.getPosX() && xBullet <= t.getPosX() + t.getWidth()
                                    && yBullet >= t.getPosY() && yBullet <= t.getPosY() + t.getHeight()) {
                                aux.add(t);
                                aux.add(b);
                            }
                        }
                    }
                }
            }
        }
        for (int i = 0; i < aux.size(); i++) {
            panel.removeObject(aux.get(i));
            shapes.remove(aux.get(i));
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
