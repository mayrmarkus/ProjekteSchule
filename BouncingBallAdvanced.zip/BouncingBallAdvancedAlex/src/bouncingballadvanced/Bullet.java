/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bouncingballadvanced;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Administrator
 */
public class Bullet implements Shape {

    private int x, y, speed, radius;
    private Color color;

    public Bullet(int x, int y, int speed, int radius, Color color) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.radius = radius;
        this.color = color;
    }

    @Override
    public void move(BallCage cage) {
        y = y - speed;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(color);
        g.fillOval((x - radius), (y - radius), (2 * radius), (2 * radius));
    }

    public int getPosX() {
        return x;
    }

    public int getPosY() {
        return y;
    }

    public int getWidth() {
        return radius;
    }

    public int getHeight() {
        return radius;
    }
}
